<?php
if($_GET['nome']!="" && $_GET['cognome']!="" && $_GET['email']!="")               				//controlla che siano stati impostati tutti i parametri
{	
    include "CollegamentoSQL.php";     								 							//si collega al file php che effettua la connessione al database	
																								//Passaggio/acquisizione parametri e conseguente settaggio delle variabili che li ospiteranno prevenendo eventuali manipolazioni di malintenzionati
    $nome = $conn-> real_escape_string(htmlentities($_GET['nome']));
    $cognome = $conn-> real_escape_string(htmlentities($_GET['cognome']));
    $email = $conn-> real_escape_string(htmlentities($_GET['email']));
	
	$sql = "SELECT * FROM registro";                            								//Dichiarazione query di select
    $risposta = $conn->query($sql);      
	
	$controllo_esistenza=false;																	//Vado a verificare che il nome ed il cognome non siano già stati inseriti controllando ogni record
    while ($record = $risposta->fetch_assoc()) 
	{                            
        if ($record["Nome"]==$nome && $record["Cognome"]==$cognome) 
		{       
            $controllo_esistenza = true;                                    
            break;
        }
    }
	
	if(!filter_var($email, FILTER_VALIDATE_EMAIL)) 												//Controllo che la mail sia valida
	{
		if ($controllo_esistenza==false)		                               		   	        //Controllo che i campi non sono stati inseriti
		{
			$sql = "INSERT INTO registro ( Nome, Cognome, Email) VALUES ('$nome', '$cognome', '$email')";	//Creo/dichiaro/definisco query
			$conn->query($sql);                                                  		//La eseguo
			echo "";
		}
		else 
			echo "E' già registrata una persona con nome e cognome uguali a quelli da lei inseriti"; 
	}
	else 
		echo "E' stata inserita una email non valida"
	
    if ($conn->query($sql) != TRUE)                    											 // dopo aver eseguito la query controlla che non vi siano stati errori durante l'inserimento dei dati
        echo "Error: " . $sql . "<br>" . $conn->error;

	$conn->close();                                               								 //Interrompo la connessione
    echo "<script> Aggiunta_Visibile (); </script>";    										 //richiamo la funzione javascript che toglie visibilità ai campi di inserimento
}