<?php
$servername = "localhost";                                      		//nome del server
$username = "root";                                             		//nome utente
$password = "";                                                 		//password
$dbname = "databaseamatidelucca";                              		    //nome del database
$conn = new mysqli($servername, $username, $password, $dbname);		    //instaurazione della connessione con il database
if ($conn->connect_error)          							    		//Verifica che non vi siano stati problemi durante 
	die("Connection failed: " . $conn->connect_error);					// la connessione (impossibilità di stabilirla)       