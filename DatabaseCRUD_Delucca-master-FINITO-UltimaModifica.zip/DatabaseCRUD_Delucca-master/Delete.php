<?php
include "CollegamentoSQL.php";     						    		//si collega al file php che effettua la connessione al database	
$Id= $conn-> real_escape_string(htmlentities($_GET['id'])); 		// acquisizione parametro id prevenendo eventuali manipolazioni di malintenzionati
$sql = "DELETE FROM registro WHERE Id=$Id";
if ($conn->query($sql) != TRUE)										//Controllo che l'operazione sia andata a buon fine
    echo "Error deleting record: " . $conn->error;
$conn->close();														//Chiudo la connessione
?>
