<?php
if($_GET['nome']!="" && $_GET['cognome']!="" && $_GET['email']!="" && $_GET['id']!="")      	 		//controlla che siano stati impostati tutti i parametri
{
    include "CollegamentoSQL.php";     															 		//si collega al file php che effettua la connessione al database	
																										//Passaggio/acquisizione parametri e conseguente settaggio delle variabili che li ospiteranno
    $name = $conn-> real_escape_string(htmlentities($_GET['nome']));
    $cognome = $conn-> real_escape_string(htmlentities($_GET['cognome']));
    $email = $conn-> real_escape_string(htmlentities($_GET['email']));
    $Id = $conn->real_escape_string(htmlentities($_GET['id']));
	
	if(!filter_var($email, FILTER_VALIDATE_EMAIL)) 												 		//Controllo che la mail sia valida
	{
		$sql = "UPDATE registro SET Nome='$name', Cognome='$cognome', Email='$email' WHERE Id='$Id'";   //Effettua l'aggiornamento dei dati del record in questione (tramite l'id)
		if ($conn->query($sql) != TRUE)                     											// dopo aver eseguito la query controlla che non vi siano stati errori durante l'aggiornamento dei dati
			echo "Error updating record: " . $conn->error;
		$conn->close(); 																				//chiude la connessione
	}
	else 
		echo "E' stata inserita una email non valida";
	
    echo "<script> Modifica_Visibile (); </script>";    												//richiama la funzione javascript che toglie visibilità ai campi di modifica
}