function Aggiunta_Visibile()
{
    $('#Aggiunta').hide();      //toglie la visibilità alla barra dei parametri da aggiungere
}
function Modifica_Visibile()
{
    $('#Modifica').hide();      //toglie la visibilità alla barra dei parametri da modificare
}